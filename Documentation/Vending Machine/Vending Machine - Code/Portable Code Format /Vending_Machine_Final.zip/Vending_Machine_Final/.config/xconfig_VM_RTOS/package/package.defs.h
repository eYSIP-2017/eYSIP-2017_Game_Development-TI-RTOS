/*
 *  Do not modify this file; it is automatically 
 *  generated and any modifications will be overwritten.
 *
 * @(#) xdc-B06
 */

#ifndef xconfig_VM_RTOS__
#define xconfig_VM_RTOS__



#endif /* xconfig_VM_RTOS__ */ 
