/*
 *  Do not modify this file; it is automatically 
 *  generated and any modifications will be overwritten.
 *
 * @(#) xdc-B06
 */

#ifndef xconfig_gameConsoleRTOS__
#define xconfig_gameConsoleRTOS__



#endif /* xconfig_gameConsoleRTOS__ */ 
